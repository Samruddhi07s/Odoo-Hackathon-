// db.js
const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',          // ✅ Your MySQL username
  password: '',          // ✅ Your MySQL password (empty if using XAMPP default)
  database: 'stackit_db'    // ✅ Database name you're using
});
// req.body contains: name, email, password
const hashedPassword = await bcrypt.hash(password, 10);

await db.execute(
  "INSERT INTO users (name, email, password) VALUES (?, ?, ?)",
  [name, email, hashedPassword]
);
connection.connect((err) => {
  if (err) {
    console.error('❌ DB Connection Failed:', err.stack);
    return;
  }
  console.log('✅ Connected to DB as id ' + connection.threadId);
});

module.exports = connection;