// server.js
const express = require('express');
const app = express();
const db = require('./db');
const cors = require('cors');

app.use(cors());
app.use(express.json());

// Notification count (in-memory example, replace with DB logic if needed)
let notifications = [];

// Submit question
app.post('/api/questions', (req, res) => {
  const { title, description, tags, user_id } = req.body;
  const sql = 'INSERT INTO questions (title, description, tags, user_id) VALUES (?, ?, ?, ?)';
  db.query(sql, [title, description, tags, user_id], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });

    // Add a new notification for the question
    notifications.push({ id: result.insertId, type: 'new-question', message: 'A new question was posted.' });

    res.json({ message: 'Question submitted', questionId: result.insertId });
  });
});

// Get all questions (with optional pagination)
app.get('/api/questions', (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = 5;
  const offset = (page - 1) * limit;

  db.query('SELECT COUNT(*) AS count FROM questions', (err, countResult) => {
    if (err) return res.status(500).json({ error: err.message });
    const total = countResult[0].count;

    db.query('SELECT * FROM questions ORDER BY created_at DESC LIMIT ? OFFSET ?', [limit, offset], (err, results) => {
      if (err) return res.status(500).json({ error: err.message });

      res.json({ questions: results, total });
    });
  });
});

// Get notifications (could be filtered by user later)
app.get('/api/notifications', (req, res) => {
  res.json({ notifications });
});

// Mark all notifications as read (optional)
app.post('/api/notifications/clear', (req, res) => {
  notifications = [];
  res.json({ message: 'Notifications cleared' });
});

app.listen(3000, () => {
  console.log('✅ Server running on http://localhost:3000');
});

