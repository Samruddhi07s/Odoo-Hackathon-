const db = require('../db');

exports.getAllQuestions = (req, res) => {
  const sql = `
    SELECT q.id, q.title, q.description, q.created_at, u.username
    FROM questions q
    JOIN users u ON q.user_id = u.id
    ORDER BY q.created_at DESC
  `;
  db.query(sql, (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

exports.postQuestion = (req, res) => {
  const { user_id, title, description } = req.body;
  const sql = 'INSERT INTO questions (user_id, title, description) VALUES (?, ?, ?)';
  db.query(sql, [user_id, title, description], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: 'Question posted', id: result.insertId });
  });
};
