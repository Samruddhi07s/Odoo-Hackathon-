const db = require('../db');
const { createNotification } = require('./notificationsController');


exports.postAnswer = (req, res) => {
  const { question_id, user_id, content } = req.body;
  const sql = 'INSERT INTO answers (question_id, user_id, content) VALUES (?, ?, ?)';
  db.query(sql, [question_id, user_id, content], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });

    // 🔔 Notify the question author
    const qSql = 'SELECT user_id FROM questions WHERE id = ?';
    db.query(qSql, [question_id], (err, results) => {
      if (!err && results.length > 0) {
        const questionOwnerId = results[0].user_id;
        if (questionOwnerId !== user_id) {
          createNotification(questionOwnerId, `Someone answered your question.`);
        }
      }
    });

    res.json({ message: 'Answer posted', id: result.insertId });
  });
};


exports.getAnswersByQuestionId = (req, res) => {
  const questionId = req.params.questionId;
  const sql = `
    SELECT a.id, a.content, a.is_accepted, a.created_at, u.username
    FROM answers a
    JOIN users u ON a.user_id = u.id
    WHERE a.question_id = ?
    ORDER BY a.created_at ASC
  `;
  db.query(sql, [questionId], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};
