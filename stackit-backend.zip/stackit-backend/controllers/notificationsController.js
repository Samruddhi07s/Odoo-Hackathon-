const db = require('../db');

// Create a notification
exports.createNotification = (recipient_id, message) => {
  const sql = `INSERT INTO notifications (recipient_id, message) VALUES (?, ?)`;
  db.query(sql, [recipient_id, message], (err) => {
    if (err) console.error('🔔 Error creating notification:', err.message);
  });
};

// Get all notifications for a user
exports.getNotifications = (req, res) => {
  const userId = req.params.userId;
  const sql = `SELECT * FROM notifications WHERE recipient_id = ? ORDER BY created_at DESC`;
  db.query(sql, [userId], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

// Mark all as read
exports.markAllRead = (req, res) => {
  const userId = req.params.userId;
  const sql = `UPDATE notifications SET is_read = TRUE WHERE recipient_id = ?`;
  db.query(sql, [userId], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "All notifications marked as read" });
  });
};
